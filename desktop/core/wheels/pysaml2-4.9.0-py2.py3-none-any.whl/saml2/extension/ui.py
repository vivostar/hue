import warnings as _warnings

from saml2.extension.mdui import *


_warnings.warn(
    "saml2.extension.ui is deprecated; use saml2.extension.mdui instead.",
    DeprecationWarning,
)
